# Kingmaker — Sports Demo Website

A responsive, single-page HTML prototype with a gold theme, sample cricket and football match cards, illustrative odds, a demo selection slip, a virtual-credit balance, local activity history, a demo profile form, and a prototype admin dashboard.

## Run locally
1. Extract `kingmaker-demo.zip`.
2. Open `index.html` in a modern browser (Chrome, Edge, Firefox, or Safari).
3. No build tools or dependencies are required.

Some browsers restrict localStorage on `file://` URLs. If saving does not work, run a local server from the extracted folder:
- Python: `python -m http.server 8000`
- Then open `http://localhost:8000`

## Publish
Upload `index.html` to a static hosting service such as GitHub Pages, Netlify, or Cloudflare Pages. This prototype does not require a build step. For Netlify, you can drag and drop the extracted folder in the dashboard.

## Important limitations
- Match data and odds are fictional examples and are not live.
- Virtual credits have no cash value. There are no real-money deposits, withdrawals, or payment integrations.
- Profile and activity data are stored only in the browser's localStorage; there is no backend, real authentication, or secure admin authorization.
- Before launching any real-money gambling product, obtain jurisdiction-specific legal advice and required licenses, age controls, responsible-play safeguards, secure server-side authentication, audited payments, and compliance systems.
